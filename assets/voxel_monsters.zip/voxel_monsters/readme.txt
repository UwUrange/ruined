This is a copy, please refer to the website for the latest terms of use.
https://seyauni.itch.io/voxel-monsters

This asset is free of charge.
Free for commercial use.

Prohibitions
- Claim that the copyright of this asset has been transferred to you.
- Redistribution of the asset itself.